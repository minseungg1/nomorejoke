document.getElementById('profile-image').addEventListener('click', function() {
    document.getElementById('profile-input').click();
});

document.getElementById('profile-input').addEventListener('change', function() {
    // Automatically submit the form when a file is selected
    document.getElementById('profile-form').submit();
});

const userType = "{{ user_type }}";
document.getElementById('password-edit-button').addEventListener('click', function() {
    if (userType === 'naver' || userType === 'kakao' || userType === 'google') {
        alert('소셜 회원가입은 비밀번호 수정이 불가능합니다!');
    } else {
        window.location.href = "{{ url_for('change_password_handler') }}";
    }
});
