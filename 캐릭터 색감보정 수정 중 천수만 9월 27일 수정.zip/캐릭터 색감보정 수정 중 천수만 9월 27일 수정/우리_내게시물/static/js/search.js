document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('search-input');
    const postList = document.getElementById('post-list');

    searchInput.addEventListener('input', function () {
        const query = searchInput.value.trim();
        
        if (query.length > 0) {
            fetch(`/search?query=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    postList.innerHTML = ''; // Clear previous results
                    
                    if (data.posts.length > 0) {
                        data.posts.forEach(post => {
                            const postCard = `
                                <div class="post-card">
                                    <a href="/post/${post._id}" class="post-link">
                                        <span>${post.region}</span>
                                        <div class="image-placeholder">
                                            <img src="/static/${post.image_path}" alt="Post Image">
                                        </div>
                                        <div class="post-author">
                                            <span>${post.nickname}</span>
                                        </div>
                                    </a>
                                </div>`;
                            postList.insertAdjacentHTML('beforeend', postCard);
                        });
                    } else {
                        postList.innerHTML = '<p>No posts found</p>';
                    }
                });
        } else {
            postList.innerHTML = '<p>Please enter a search term</p>';
        }
    });
});
