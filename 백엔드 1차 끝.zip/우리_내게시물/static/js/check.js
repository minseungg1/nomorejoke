
window.onload = function() {
    setTimeout(function() {
        window.location.href = "home.html";
    }, 10000); // Redirects after 10 seconds
};
