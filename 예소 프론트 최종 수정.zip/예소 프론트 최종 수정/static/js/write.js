function loadFile(input) {
    let file = input.files[0]; // 선택파일 가져오기

    let newImage = document.createElement("img"); //새 이미지 태그 생성

    //이미지 source 가져오기
    newImage.src = URL.createObjectURL(file);
    newImage.style.width = "100%"; //div에 꽉차게 넣으려고
    newImage.style.height = "100%";
    newImage.style.objectFit = "cover"; // div에 넘치지 않고 들어가게

    //이미지를 image-show div에 추가
    let container = document.getElementById('image-show');
    container.appendChild(newImage);
}

document.querySelector('.upload-btn').addEventListener('click', function() {
    alert('글이 업로드되었습니다.');
        // function hat2Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('form').addEventListener('submit', function(event) {
    // 각 태그에 대해 체크박스가 선택되지 않았으면 기본값 설정
    if (document.getElementById('age-input').value === '') {
        document.getElementById('age-input').value = '미선택';
    }
    if (document.getElementById('gender-input').value === '') {
        document.getElementById('gender-input').value = '미선택';
    }
    if (document.getElementById('travel-type-input').value === '') {
        document.getElementById('travel-type-input').value = '미선택';
    }
    if (document.getElementById('region-input').value === '') {
        document.getElementById('region-input').value = '미선택';
    }
    if (document.getElementById('cost-input').value === '') {
        document.getElementById('cost-input').value = '미선택';
    }
    if (document.getElementById('relationship-input').value === '') {
        document.getElementById('relationship-input').value = '미선택';
    }
});







// -------------------------------------------- //







// 모달 열기
// 모달 열기
// 모달 열기
function openModal(modalId) {
    document.getElementById(modalId).style.display = "block";
}

// 모달 닫기
function closeModal(modalId) {
    document.getElementById(modalId).style.display = "none";
}

// 세분화된 지역 모달 열기
function openSubRegionModal(modalId) {
    closeModal('region-modal'); // 기존 지역 모달 닫기
    openModal(modalId); // 세분화된 지역 모달 열기
}

// 모달 외부 클릭 시 닫기
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let i = 0; i < modals.length; i++) {
        if (event.target == modals[i]) {
            modals[i].style.display = "none";
        }
    }
}

// 텍스트 대체 함수
function selectOption(buttonId, value, inputId) {
    document.getElementById(buttonId).innerText = value;  // 버튼의 텍스트를 업데이트
    document.getElementById(inputId).value = value;       // 숨겨진 input 필드에 값 설정
    closeModal(buttonId.replace('button', 'modal'));      // 선택 후 모달 닫기
}