from twilio.rest import Client
account_sid = 'AC421e60e4afa9350b47de8f6955bc2412'
auth_token = 'c5c0c70acec8f52793cd911b6b97dea4'
client = Client(account_sid, auth_token)
message = client.messages.create(
  from_='+12674045433',
  body='제발용',
  to='+821033107269'
)
print(message.sid)
