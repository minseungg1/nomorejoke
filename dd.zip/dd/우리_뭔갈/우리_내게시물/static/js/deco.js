document.querySelector('.hat1').addEventListener('click', function() {
    alert('밀짚 모자가 착용되었습니다.');
    // function hat1Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.hat2').addEventListener('click', function() {
    alert('캡 모자가 착용되었습니다.');
        // function hat2Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.hat3').addEventListener('click', function() {
    alert('사과 모자가 착용되었습니다.');
        // function hat3Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.hat4').addEventListener('click', function() {
    alert('귤 모자가 착용되었습니다.');
        // function hat4Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.hat5').addEventListener('click', function() {
    alert('왕관 모자가 착용되었습니다.');
        // function hat5Img() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.reset-button').addEventListener('click', function() {
    alert('초기화 버튼이 클릭되었습니다.');
        // function resetImg() {
    //     document.getElementById("img").src = "./images/rose.jpg";
});

document.querySelector('.apply-button').addEventListener('click', function() {
    alert('적용 버튼이 클릭되었습니다.');
});

