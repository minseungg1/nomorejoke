import requests
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from pymongo import MongoClient
import os
from werkzeug.security import generate_password_hash, check_password_hash
from random import randint
from werkzeug.utils import secure_filename
from bson import ObjectId
from twilio.rest import Client
import os
import uuid
import base64
from twilio.base.exceptions import TwilioRestException
import random


app = Flask(__name__)
app.secret_key = os.urandom(24)

# MongoDB connection setup
client = MongoClient('localhost', 27017)
db_user = client['userdata']
users_collection = db_user['users']
db_rec = client['travel_records']
posts_collection = db_rec['posts']

# Naver Client credentials
NAVER_CLIENT_ID = "GdIVUzVIlAHmauyp8JdZ"
NAVER_CLIENT_SECRET = "gTJTldHlax"
NAVER_REDIRECT_URI = "http://localhost:5000/naver/callback"

# Google Client credentials
GOOGLE_CLIENT_ID = "188913799592-g60b5csrcum580b8paluehhes1vgi4f5.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = "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"
GOOGLE_REDIRECT_URI = "http://localhost:5000/google/callback"

NAVER_AUTH_URL = "https://nid.naver.com/oauth2.0/authorize?response_type=code"
NAVER_TOKEN_URL = "https://nid.naver.com/oauth2.0/token"
NAVER_USER_INFO_URL = "https://openapi.naver.com/v1/nid/me"

GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USER_INFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo"
@app.route('/')
@app.route('/ready')
def ready():
    if 'user_id' not in session:
        return redirect(url_for('login'))  # Redirect to login if not authenticated
    return render_template('ready.html')  # Render ready.html after successful login
# Login route
import hashlib
def hash_password(password):
    # 새로운 salt 값 생성
    salt = os.urandom(16).hex()  # 16바이트의 임의의 salt 값 생성
    # n 값을 16384로 줄여서 해시 생성
    hashed_password = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()
    return f"scrypt:16384:8:1${salt}${hashed_password}"
def verify_scrypt_password(stored_password, input_password):
    try:
        # 저장된 비밀번호 해시를 구성 요소로 분리
        components = stored_password.split('$')
        scrypt_params = components[0]  # 'scrypt:16384:8:1'
        salt = components[1]  # salt 값
        stored_hash = components[2]  # 실제 저장된 해시 값

        # scrypt 파라미터에서 n, r, p 값 추출
        n, r, p = map(int, scrypt_params.split(':')[1:])

        # 입력된 비밀번호를 동일한 파라미터로 해시
        scrypt_hash = hashlib.scrypt(input_password.encode(), salt=salt.encode(), n=n, r=r, p=p).hex()

        # 해시된 입력 비밀번호와 저장된 해시를 비교
        return scrypt_hash == stored_hash
    except Exception as e:
        print(f"Error verifying password: {e}")
        return False




@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        password = request.form.get('password')

        if not user_id or not password:
            print('아이디와 비밀번호를 모두 입력해주세요.', 'error')
            return render_template('login.html', error=True)

        # MongoDB에서 user_id로 사용자 찾기
        user = users_collection.find_one({'user_id': user_id})
        if user:
            hashed_password = user.get('password')
    
            print(hashed_password)
            print(password)
            
            if verify_scrypt_password(hashed_password, password):
                session['user_id'] = user['user_id']
                return redirect(url_for('ready_view'))
            else:
                 print('아이디 또는 비밀번호가 잘못되었습니다q.', 'error')
        else:
             print('아이디 또는 비밀번호가 잘못되었습니다w.', 'error')

    return render_template('login.html', error=True)


@app.route('/kakao', methods=["GET"])
def kakao():
    kakao_user_id = session.get('kakao_user_id')

    if not kakao_user_id:
        return redirect(url_for('login'))  # 세션에 사용자 ID가 없으면 로그인 페이지로 리디렉션

    user = users_collection.find_one({"user_id": kakao_user_id})
    print(f"User fetched from DB: {user}")  # 디버깅을 위해 사용자 정보 출력

    if user and 'phone_number' in user and user['phone_number'].strip():
        return redirect(url_for('ready'))
    else:
        return render_template('make_name.html')

@app.route('/kakao/register', methods=['POST'])
def kakao_register():
    data = request.json
    kakao_user_id = data.get('kakao_id')
    nickname = data.get('nickname')

    if not kakao_user_id:
        return jsonify({"success": False, "message": "Kakao ID is missing"}), 400

    # Set Kakao user ID as 'user_id' in session
    session['user_id'] = kakao_user_id

    # Insert or update the user's kakao_id, nickname, and type in the database
    users_collection.update_one(
        {"user_id": kakao_user_id},
        {"$set": {"nickname": nickname, "type": "kakao"}},  # Set the type as 'kakao'
        upsert=True
    )

    # Redirect to the next step (make_name) after Kakao login
    return jsonify({"success": True, "redirect_url": url_for('make_name')}), 200


# Route for Naver login
@app.route('/naver/login')
def naver_login():
    return redirect(f"{NAVER_AUTH_URL}&client_id={NAVER_CLIENT_ID}&redirect_uri={NAVER_REDIRECT_URI}&state=naver_login")

@app.route('/naver/callback')
def naver_callback():
    code = request.args.get('code')
    state = request.args.get('state')

    token_request = requests.post(
        NAVER_TOKEN_URL,
        params={
            "grant_type": "authorization_code",
            "client_id": NAVER_CLIENT_ID,
            "client_secret": NAVER_CLIENT_SECRET,
            "code": code,
            "state": state,
        }
    )
    
    token_response_data = token_request.json()
    access_token = token_response_data.get('access_token')

    if not access_token:
        return jsonify({"success": False, "message": "Failed to retrieve access token"}), 400

    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    user_info_request = requests.get(NAVER_USER_INFO_URL, headers=headers)
    user_info = user_info_request.json()

    if user_info['resultcode'] == "00":
        naver_user_data = user_info['response']
        naver_user_id = naver_user_data['id']

        # Set Naver user ID as 'user_id' in session
        session['user_id'] = naver_user_id

        users_collection.update_one(
            {"user_id": naver_user_id},
            {"$set": {"user_id": naver_user_id, "type": "naver"}},  # Set the type as 'naver'
            upsert=True
        )

        return redirect(url_for('make_name'))
    else:
        return jsonify({"success": False, "message": "Failed to retrieve user information from Naver"}), 400



# Route for Google login
@app.route('/google/login')
def google_login():
    return redirect(f"{GOOGLE_AUTH_URL}?response_type=code&client_id={GOOGLE_CLIENT_ID}&redirect_uri={GOOGLE_REDIRECT_URI}&scope=email%20profile")

# Route for Google login
@app.route('/google/callback')
def google_callback():
    code = request.args.get('code')

    token_request = requests.post(
        GOOGLE_TOKEN_URL,
        data={
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": GOOGLE_REDIRECT_URI,
            "grant_type": "authorization_code",
        }
    )

    token_response_data = token_request.json()
    access_token = token_response_data.get('access_token')

    if not access_token:
        return jsonify({"success": False, "message": "Failed to retrieve access token"}), 400

    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    user_info_request = requests.get(GOOGLE_USER_INFO_URL, headers=headers)
    user_info = user_info_request.json()

    google_user_id = user_info['sub']

    # Set Google user ID as 'user_id' in session
    session['user_id'] = google_user_id

    users_collection.update_one(
        {"user_id": google_user_id},
        {"$set": {"user_id": google_user_id,  "type": "google"}},  # Set the type as 'google'
        upsert=True
    )

    return redirect(url_for('make_name'))

@app.route('/make_id', methods=['GET', 'POST'])
def make_id():
    session.clear()  # Clear session to prevent duplication
    if request.method == 'POST':
        user_id = request.form['user_id']
        
        # Check if the user ID already exists
        if users_collection.find_one({"user_id": user_id}):
            flash('아이디가 이미 존재합니다.', 'error')
            return redirect(url_for('make_id'))
        else:
            # Save the user ID and type in MongoDB
            try:
                users_collection.insert_one({"user_id": user_id, "type": "general"})  # Set the type as 'general'
                session['user_id'] = user_id  # Save the user ID in the session for the next steps
                flash('아이디가 성공적으로 생성되었습니다.', 'success')
                return redirect(url_for('make_pw'))  # Redirect to the password setup page
            except Exception as e:
                flash('데이터 저장 중 오류가 발생했습니다.', 'error')
                return redirect(url_for('make_id'))
    
    # If it's a GET request, render the make_id page
    return render_template('make_id.html')


@app.route('/check_id', methods=['POST'])
def check_id():
    user_id = request.json.get('user_id')  # 클라이언트로부터 전달된 아이디 값

    if not user_id:
        return jsonify({"success": False, "message": "아이디를 입력해 주세요."}), 400

    # MongoDB에서 아이디 중복 확인
    user = users_collection.find_one({"user_id": user_id})

    if user:
        return jsonify({"success": False, "message": "이미 사용 중인 아이디입니다."}), 409
    else:
        return jsonify({"success": True, "message": "사용 가능한 아이디입니다."}), 200
from werkzeug.security import generate_password_hash

@app.route('/make_pw', methods=['GET', 'POST'])
def make_pw():
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # 비밀번호 일치 확인
        if password != confirm_password:
            flash('비밀번호가 일치하지 않습니다.', 'error')
            return redirect(url_for('make_pw'))

        # 로그인 유형 확인 및 소셜 로그인 계정에서 비밀번호 설정 방지
        login_type = session.get('login_type')
        user_id = session.get('user_id')

        if login_type in ['google', 'naver', 'kakao']:
            flash('소셜 로그인 계정에 비밀번호를 설정할 수 없습니다.', 'error')
            return redirect(url_for('make_pw'))

        if user_id:
            # scrypt를 이용하여 비밀번호 해시 생성
            hashed_password = hash_password(password)
            try:
                # 일반 회원가입 사용자에 한해 비밀번호 업데이트
                users_collection.update_one(
                    {"user_id": user_id},
                    {"$set": {"password": hashed_password}}
                )
                flash('비밀번호가 성공적으로 설정되었습니다.', 'success')
                return redirect(url_for('make_name'))
            except Exception as e:
                flash('데이터 저장 중 문제가 발생했습니다. 다시 시도해주세요.', 'error')
                return redirect(url_for('make_pw'))

    return render_template('make_pw.html')

  

# Route for name creation
@app.route('/verify_code', methods=['POST'])
def verify_code():
    data = request.get_json()
    entered_code = data['verification_code']
    saved_code = session.get('verification_code')

    if entered_code == saved_code:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False})

@app.route('/make_name', methods=['GET', 'POST'])
def make_name():
    user_id = session.get('user_id')
    print(f"Session user_id: {user_id}")  # Debug: Check if user_id is correctly stored in session
    
    if not user_id:
        return redirect(url_for('login'))

    # Fetch the user's name directly from the MongoDB database
    user = users_collection.find_one({"user_id": user_id})
    name = user.get('name') if user else None
    print(f"User name from DB before POST: {name}")  # Debug: Check if the name is already stored in the database
    
    # If the name is already in the database, redirect to the ready page
    if name:
        return redirect(url_for('ready'))

    if request.method == 'POST':
        # Retrieve the name from the form POST data
        name = request.form.get('name')
        print(f"Form name from POST: {name}")  # Debug: Check if name is coming from the form

        if not name:
            # Handle error if no name is provided
            flash('이름을 입력해 주세요.', 'error')
            print("Error: No name provided in POST request")  # Debug message for missing name
            return redirect(url_for('make_name'))

        # Update the user's name in MongoDB
        try:
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {"name": name}}
            )
            print(f"User name updated in MongoDB for user_id: {user_id}, name: {name}")
        except Exception as e:
            # Handle any errors that occur during the database update
            flash('이름 업데이트 중 오류가 발생했습니다.', 'error')
            print(f"Error updating name in MongoDB: {e}")  # Debug message for DB update error
            return redirect(url_for('make_name'))

        # After successfully setting the name, redirect to the next step (make_nickname)
        return redirect(url_for('make_nickname'))

    return render_template('make_name.html')

# Route for nickname creation
@app.route('/make_nickname', methods=['GET', 'POST'])
def make_nickname():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    user_data = users_collection.find_one({"user_id": user_id})

    if user_data:
        user_type = user_data.get('type')
        if user_type in ['naver', 'kakao', 'google']:
            # password 필드를 "NULL"로 업데이트
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {"password": "NULL"}}
            )

    if request.method == 'POST':
        nickname = request.form['nickname']
        users_collection.update_one(
            {"user_id": user_id},
            {"$set": {"nickname": nickname}}
        )
        session['nickname'] = nickname
        return redirect(url_for('make_phone'))

    return render_template('make_nickname.html')

@app.route('/check_nickname', methods=['POST'])
def check_nickname():
    data = request.get_json()
    user_nickname = data.get('user_nickname')

    # Check if the nickname already exists in the database
    existing_user = users_collection.find_one({"nickname": user_nickname})

    if existing_user:
        # Nickname already exists
        return jsonify({"status": "duplicate", "message": "이미 사용 중인 닉네임입니다."})
    else:
        # Nickname is available
        return jsonify({"status": "available", "message": "사용 가능한 닉네임입니다."})

# Twilio API credentials
account_sid = 'AC421e60e4afa9350b47de8f6955bc2412'
auth_token = 'c5c0c70acec8f52793cd911b6b97dea4'
client = Client(account_sid, auth_token)


# Helper function to format the phone number
def ver_phone_num(phone_number):
    """Formats the phone number for Korea."""
    if phone_number.startswith('010'):
        return '+82' + phone_number[1:]  # Remove the leading 0 and add '+82'
    else:
        raise ValueError('Invalid phone number format')

# Function to send a verification code
def send_verification_code(phone_number):
    """Sends a verification code to the given phone number."""
    formatted_number = ver_phone_num(phone_number)  # Format the phone number
    verification_code = randint(100000, 999999)  # Generate random 6-digit code
    
    try:
        message = client.messages.create(
            from_='+12674045433',  # Twilio phone number
            body=f'인증번호: {verification_code}',  # Send the code in the message body
            to=formatted_number  # Use formatted phone number
        )
        print(f"Message sent, SID: {message.sid}")
        return verification_code
    except Exception as e:
        print(f"Error sending message: {e}")
        return None
@app.route('/send_verification', methods=['POST'])
def send_verification():
    data = request.get_json()
    phone_number = data['phone_number']

    try:
        # Send the verification code here
        sent_code = send_verification_code(phone_number)
        session['verification_code'] = str(sent_code)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/make_phone', methods=['GET', 'POST'])
def make_phone():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    # Fetch user from the database
    user = users_collection.find_one({"user_id": user_id})

    # If user doesn't have 'credits', 'stack_credit', or 'nocheck' fields, set them to 0
    if 'credits' not in user or 'stack_credit' not in user or 'nocheck' not in user:
        update_fields = {}
        if 'credits' not in user:
            update_fields['credits'] = 0
            user['credits'] = 0  # Update the in-memory user object
        if 'stack_credit' not in user:
            update_fields['stack_credit'] = 0
            user['stack_credit'] = 0  # Update the in-memory user object
        if 'nocheck' not in user:
            update_fields['nocheck'] = 0
            user['nocheck'] = 0  # Update the in-memory user object

        if update_fields:
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": update_fields}
            )

    if request.method == 'POST':
        phone_number = request.form['phone_number']

        # Check if the verification code was submitted
        verification_code = request.form.get('verification_code')
        saved_code = session.get('verification_code')

        # Allow "test-user" to bypass verification
        if verification_code == "test-user" or (verification_code and saved_code):
            # Verify the code
            if verification_code == "test-user" or verification_code == saved_code:
                # Code matches, save the phone number to the database
                users_collection.update_one(
                    {"user_id": user_id},
                    {"$set": {"phone_number": phone_number}}
                )
                session.pop('verification_code', None)  # Remove the code from session after use
                return redirect(url_for('make_profile'))
            else:
                # Code doesn't match, show an error message
                flash('인증번호가 일치하지 않습니다. 다시 시도해주세요.')
        else:
            # No verification code submitted yet, so send one
            sent_code = send_verification_code(phone_number)
            if sent_code:
                session['verification_code'] = str(sent_code)  # Save the code in session
                flash('인증번호가 전송되었습니다. 확인 후 입력해주세요.')
            else:
                flash('메시지 전송에 실패했습니다. 나중에 다시 시도해주세요.')

    return render_template('make_phone.html', credits=user['credits'], stack_credit=user['stack_credit'], nocheck=user['nocheck'])

# Route for profile creation (file upload)
@app.route('/make_profile', methods=['GET', 'POST'])
def make_profile():
    user_id = session.get('user_id') 

    if not user_id:
        return redirect(url_for('login'))

    if request.method == 'POST':
        profile_image = request.files['profile_image']
        upload_folder = 'static/image/uploads_profile'  # Updated folder path

        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        if profile_image:
            profile_image.save(os.path.join(upload_folder, profile_image.filename))
            profile_image_path = f'/static/image/uploads_profile/{profile_image.filename}'  # Updated path
        else:
            profile_image_path = '/static/image/profile.png'

        # 소셜 로그인 여부 확인 (소셜 로그인일 경우 비밀번호를 건드리지 않음)
        if session.get('kakao_user_id') or session.get('naver_user_id') or session.get('google_user_id'):
            # 소셜 로그인 사용자는 비밀번호 없이 프로필 이미지 업데이트
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {
                    "profile_image": profile_image_path,
                    "password": None
                }}
            )
        else:
            # 일반 회원가입 사용자의 경우 비밀번호를 건드리지 않고 프로필 이미지만 업데이트
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {
                    "profile_image": profile_image_path
                }}
            )

        flash('회원가입이 완료되었습니다!', 'success')
        return redirect(url_for('choose'))

    return render_template('make_profile.html')

@app.route('/choose')
def choose():
    return render_template('choose.html')
@app.route('/choose2')
def choose2():
    return render_template('choose2.html')

@app.route('/choose3')
def choose3():
    return render_template('choose3.html')


@app.route('/make_profile')
def make_profile_view():
    return render_template('make_profile.html')

@app.route('/ready')
def ready_view():
    return render_template('ready.html')

@app.route('/save_gender', methods=['POST'])
def save_gender():
    user_id = session.get('user_id') 
    
    if not user_id:
        return redirect(url_for('login'))  # 세션에 사용자 정보가 없으면 로그인 페이지로 리디렉션
    
    gender = request.form.get('gender')

    if not gender:
        flash('성별을 선택해 주세요.', 'error')
        return redirect(url_for('choose'))
    
    # MongoDB에 gender 값 업데이트
    users_collection.update_one(
        {"user_id": user_id},  # 소셜 로그인 사용자와 일반 로그인 사용자 모두 동일하게 처리
        {"$set": {"gender": gender}}
    )

    # choose2.html로 이동
    return redirect(url_for('choose2'))

@app.route('/save_age', methods=['POST'])
def save_age():
    user_id = session.get('user_id') 
    
    if not user_id:
        return redirect(url_for('login'))  # 세션에 사용자 정보가 없으면 로그인 페이지로 리디렉션

    # 폼에서 선택된 나이대 값 받기
    age = request.form.get('age')

    if not age:
        flash('나이대를 선택해 주세요.', 'error')
        return redirect(url_for('choose'))

    # MongoDB에 age 값 업데이트
    users_collection.update_one(
        {"user_id": user_id},  # 소셜 로그인 사용자와 일반 로그인 사용자 모두 동일하게 처리
        {"$set": {"age": age}}
    )

    # choose3.html로 이동
    return redirect(url_for('choose3'))

@app.route('/save_prefer', methods=['POST'])
def save_prefer():
    user_id = session.get('user_id')
    
    if not user_id:
        return redirect(url_for('login'))  # 세션에 사용자 정보가 없으면 로그인 페이지로 리디렉션
    
    # 사용자가 선택한 여행 스타일 값을 가져옵니다.
    prefer = request.form.get('prefer')

    if not prefer:
        flash('여행 스타일을 선택해 주세요.', 'error')
        return redirect(url_for('choose'))

    # MongoDB에 prefer 항목 업데이트
    users_collection.update_one(
        {"user_id": user_id},  # 소셜 로그인 사용자와 일반 로그인 사용자 모두 동일하게 처리
        {"$set": {"prefer": prefer}}
    )

    # 저장이 완료되면 ready.html로 이동
    return redirect(url_for('ready_view'))



@app.route('/find')
def find():
    return render_template('find.html')
@app.route('/find_id', methods=['GET', 'POST'])
def find_id():
    if request.method == 'POST':
        phone_number = request.form['phone_number']
        verification_code = request.form.get('verification_code')
        saved_code = session.get('verification_code')

        # Allow "test-user" to bypass verification
        if verification_code == "test-user" or (verification_code and saved_code):
            if verification_code == "test-user" or verification_code == saved_code:
                # Find the user by phone number
                user = users_collection.find_one({"phone_number": phone_number})
                if user:
                    session.pop('verification_code', None)  # Remove the code from session
                    # Pass the user_id to the template
                    return render_template('id.html', user_id=user['user_id'])  # Redirect to id.html with user_id
                else:
                    flash('해당 전화번호로 등록된 사용자를 찾을 수 없습니다.')
            else:
                flash('인증번호가 일치하지 않습니다. 다시 시도해주세요.')
        else:
            # Send the verification code if no code has been submitted yet
            sent_code = send_verification_code(phone_number)
            if sent_code:
                session['verification_code'] = str(sent_code)
                flash('인증번호가 전송되었습니다. 확인 후 입력해주세요.')
            else:
                flash('메시지 전송에 실패했습니다. 나중에 다시 시도해주세요.')

    return render_template('find_id.html')



@app.route('/id')
def id():
    return render_template('id.html')

@app.route('/find_pw', methods=['GET', 'POST'])
def find_pw():
    if request.method == 'POST':
        phone_number = request.form.get('phone_number')

        # Validate the phone number in the users collection
        user = users_collection.find_one({"phone_number": phone_number})

        if not user:
            flash('전화번호가 일치하지 않습니다.', 'error')
            return redirect(url_for('find_pw'))

        # Store the phone number in the session for future use
        session['phone_number'] = phone_number
        flash('전화번호 인증에 성공했습니다.', 'success')
        return redirect(url_for('update_password'))  # Redirect to the pw.html for password update

    return render_template('find_pw.html')

@app.route('/update_password', methods=['GET', 'POST'])
def update_password():
    if request.method == 'POST':
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        # Check if the passwords match
        if new_password != confirm_password:
            flash('비밀번호가 일치하지 않습니다.', 'error')
            return redirect(url_for('update_password'))

        # Retrieve the phone number from the session
        phone_number = session.get('phone_number')

        if not phone_number:
            flash('전화번호 인증이 필요합니다.', 'error')
            return redirect(url_for('find_pw'))

        # Hash the new password and update the user's password in the database
        hashed_password = generate_password_hash(new_password)
        try:
            users_collection.update_one(
                {"phone_number": phone_number},
                {"$set": {"password": hashed_password}}
            )
            flash('비밀번호가 성공적으로 변경되었습니다.', 'success')
            return redirect(url_for('login'))  # Redirect to login page after successful update
        except Exception as e:
            flash('비밀번호 변경 중 문제가 발생했습니다. 다시 시도해주세요.', 'error')
            return redirect(url_for('update_password'))
    
    return render_template('pw.html')  # This is your pw.html where password inputs are taken

from datetime import datetime

from datetime import datetime, timedelta

@app.route('/check', endpoint='check')
def check_view():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))  # Redirect to login if no user is logged in
    
    # Fetch user data from the database based on user_id
    user_data = users_collection.find_one({'user_id': user_id})
    
    if not user_data:
        return "User not found", 404
    
    # Get user's credits or set to 0 if not found
    credits = user_data.get('credits', 0)
    stack_credit = user_data.get('stack_credit', 0)  # Fetch stack_credit value
    
    # Get user's last check-in date
    last_check_in_date = user_data.get('last_check_in_date')
    
    # Get the current date
    today = datetime.today().date()
    
    # Initialize nocheck and check_in_count if not present
    check_in_count = user_data.get('check_in_count', 0)
    nocheck = user_data.get('nocheck', 0)

    # Check if the user has already checked in today
    already_checked_in = False
    if last_check_in_date:
        last_check_in_date = datetime.strptime(last_check_in_date, '%Y-%m-%d').date()
        if last_check_in_date == today:
            already_checked_in = True

    # If the user hasn't checked in today, perform check-in logic
    if not already_checked_in:
        # Check if there is a gap between today and the last check-in date
        if last_check_in_date:
            days_missed = (today - last_check_in_date).days
            # If days were missed (more than 1 day), increment nocheck by the number of missed days
            if days_missed > 1:
                nocheck += days_missed - 1

        # If the user hasn't reached the limit of 28 days
        if check_in_count < 28:
            check_in_count += 1
        else:
            check_in_count = 1  # Restart check-in count after 28 days
            
    

        # Update the user's data in MongoDB
        users_collection.update_one(
            {'user_id': user_id},
            {'$set': {
                'check_in_count': check_in_count,
                'last_check_in_date': today.strftime('%Y-%m-%d'),
                'nocheck': nocheck,
                'credits': credits,
                'stack_credit': stack_credit
            }}
        )
    else:
        print("Already checked in today. No credits or check-in updates.")

    # Render the template with the credits, check_in_count, nocheck, and stack_credit values
    return render_template('check.html', credits=credits, check_in_count=check_in_count, nocheck=nocheck, stack_credit=stack_credit, already_checked_in=already_checked_in)


@app.route('/update_credits', methods=['POST'])
def update_credits():
    try:
        data = request.get_json()
        print("Received data:", data)  # Debugging statement
        user_id = session.get('user_id')
        credits_to_add = data.get('credits_to_add', 0)
        
        # Fetch user data from the database
        user_data = users_collection.find_one({'user_id': user_id})
        print("User data found:", user_data)  # Debugging statement
        
        if not user_data:
            return jsonify({'error': 'User not found'}), 404
        
        # Get current credits and stack_credit, or default to 0
        current_credits = user_data.get('credits', 0)
        stack_credit = user_data.get('stack_credit', 0)
        
        # Add the credits to both fields
        new_credits = current_credits + credits_to_add
        new_stack_credit = stack_credit + credits_to_add
        
        # Update the user's credits and stack_credit in the database
        result = users_collection.update_one(
            {'user_id': user_id},
            {'$set': {
                'credits': new_credits,
                'stack_credit': new_stack_credit
            }}
        )
        
        print("Update result:", result)  # Debugging statement
        
        return jsonify({'message': 'Credits updated successfully'}), 200
    except Exception as e:
        print("Error during credits update:", str(e))  # Print error to logs
        return jsonify({'error': 'An error occurred during credits update'}), 500


@app.route('/get_credits', methods=['GET'])
def get_credits():
    user_id = session.get('user_id')

    if not user_id:
        return jsonify({'error': 'User not logged in'}), 401
    
    # Fetch the user data
    user_data = users_collection.find_one({'user_id': user_id})

    if not user_data:
        return jsonify({'error': 'User not found'}), 404

    # Return the current credits
    current_credits = user_data.get('credits', 0)
    return jsonify({'credits': current_credits}), 200


import random
from bson import ObjectId

import os
from flask import send_file

@app.route('/home', methods=['GET'])
def home_view():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))

    # Fetch user data from the database
    user_data = users_collection.find_one({'user_id': user_id})
    if not user_data:
        return "User not found", 404

    # Get the profile image and nickname from the user data
    profile_image = user_data.get('profile_image', '/static/image/uploads_profile/default_profile.png')  # Default image
    nickname = user_data.get('nickname', 'Unknown User')  # Default nickname
    
    # Get the selected region filter from the query parameters (default is '전체')
    selected_region = request.args.get('region', '전체')

    # Build the query based on the selected region
    if selected_region == '전체':
        # No filtering for "전체" (show all posts)
        region_filter = {}
    elif selected_region == '한국':
        # Filter for posts from "한국"
        region_filter = {'tags.region': {'$regex': r'.*한국$'}}  # Regex to match "한국" in the country part
    elif selected_region == '아메리카':
        # Filter for posts from both "북미" and "남미"
        region_filter = {'$or': [{'tags.region': {'$regex': r'^북미 - '}}, {'tags.region': {'$regex': r'^남미 - '}}]}
    else:
        # Filter for a continent (e.g., "아시아", "유럽")
        region_filter = {'tags.region': {'$regex': f'^{selected_region} - '}}  # Regex to match the continent

    # Fetch the top 2 posts with the most likes based on the region filter (hot posts)
    top_posts = list(posts_collection.find(region_filter, {'tags.region': 1, 'image_path': 1, 'user_id': 1, 'likes': 1}).sort('likes', -1).limit(2))

    # Add user nicknames to the hot posts and save their IDs to avoid duplicates in recommended posts
    hot_post_ids = []
    for post in top_posts:
        post_user = users_collection.find_one({'user_id': post['user_id']})
        post['nickname'] = post_user.get('nickname', 'Unknown User') if post_user else 'Unknown User'
        post['region'] = post.get('tags', {}).get('region', 'Unknown Region')
        hot_post_ids.append(post['_id'])

        # Ensure the image path is correct and read the image file
        if post.get('image_path'):
            image_path = os.path.join('static', post['image_path'])
            try:
                with open(os.path.join('static', post['image_path']), "rb") as image_file:
                    post['image_data'] = image_file.read()  # Read image file content
            except FileNotFoundError:
                post['image_data'] = None

    # Fetch all posts except the hot posts, and select 5 random posts for the recommended section
    all_posts = list(posts_collection.find({'_id': {'$nin': hot_post_ids}, **region_filter}, {'tags.region': 1, 'image_path': 1, 'user_id': 1, 'likes': 1}))
    recommended_posts = random.sample(all_posts, 5) if len(all_posts) >= 5 else all_posts

    # Add user nicknames to the recommended posts
    for post in recommended_posts:
        post_user = users_collection.find_one({'user_id': post['user_id']})
        post['nickname'] = post_user.get('nickname', 'Unknown User') if post_user else 'Unknown User'
        post['region'] = post.get('tags', {}).get('region', 'Unknown Region')

        # Ensure the image path is correct and read the image file
        if post.get('image_path'):
            image_path = os.path.join('static', post['image_path'])
            try:
                with open(os.path.join('static', post['image_path']), "rb") as image_file:
                    post['image_data'] = image_file.read()  # Read image file content
            except FileNotFoundError:
                post['image_data'] = None

    # Pass the data to the template
    return render_template('home.html', profile_image=profile_image, nickname=nickname, top_posts=top_posts, recommended_posts=recommended_posts, selected_region=selected_region)



# 파일 업로드 설정
UPLOAD_FOLDER = 'static/uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    if '.' in filename:
        ext = filename.rsplit('.', 1)[1].lower()
        return ext in ALLOWED_EXTENSIONS
    return False

def generate_unique_filename(filename):
    if '.' in filename:
        ext = filename.rsplit('.', 1)[1].lower()
    else:
        flash('파일 이름에 확장자가 없습니다.')
        return None
    unique_filename = f"{uuid.uuid4().hex}.{ext}"
    return unique_filename

@app.route('/write', methods=['GET', 'POST'])
def write():
    user_id = session.get('user_id')  # Get the user_id from the session
    if not user_id:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    popular_tags = {
        'age': get_most_common_tag_value('age'),
        'gender': get_most_common_tag_value('gender'),
        'travel_type': get_most_common_tag_value('travel_type'),
        'region': get_most_common_tag_value('region'),
        'cost': get_most_common_tag_value('cost'),
        'relationship': get_most_common_tag_value('relationship'),
        'during': get_most_common_tag_value('during'),
    }

    if request.method == 'POST':
        content = request.form.get('content', '').strip()
        age = request.form.get('age', '').strip()
        gender = request.form.get('gender', '').strip()
        travel_type = request.form.get('travel_type', '').strip()
        region = request.form.get('region', '').strip()
        cost = request.form.get('cost', '').strip()
        relationship = request.form.get('relationship', '').strip()
        during = request.form.get('during', '').strip()

        tags = {
            'age': age,
            'gender': gender,
            'travel_type': travel_type,
            'region': region,
            'cost': cost,
            'relationship': relationship,
            'during': during
        }

        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            unique_filename = generate_unique_filename(filename)
            if unique_filename:
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                file.save(file_path)
                
                # Add the default likes=0 and comments field
                post_data = {
                    'user_id': user_id,  # Add user_id to the post data
                    'content': content,
                    'image_path': f"uploads/{unique_filename}",
                    'tags': tags,
                    'likes': 0,  # Set default likes to 0
                    'comments': []  # Initialize empty comments list
                }
                
                posts_collection.insert_one(post_data)
                flash('글이 업로드되었습니다.')
                return redirect(url_for('write'))
            else:
                return redirect(url_for('write'))
        else:
            flash('허용되지 않는 파일 형식입니다.')
            return redirect(url_for('write'))

    return render_template('write.html', popular_tags=popular_tags)

@app.route('/upload', methods=['POST'])
def upload():
    user_id = session.get('user_id')  # Get the user_id from the session
    if not user_id:
        return redirect(url_for('login'))  # Redirect to login if not logged in

    content = request.form.get('content', '')

    age = request.form.get('age', '나이대')
    gender = request.form.get('gender', '성별')
    travel_type = request.form.get('travel_type', '여행 유형')
    region = request.form.get('region', '지역')
    cost = request.form.get('cost', '비용')
    relationship = request.form.get('relationship', '관계')
    during = request.form.get('during', '여행 기간')

    tags = {
        'age': age,
        'gender': gender,
        'travel_type': travel_type,
        'region': region,
        'cost': cost,
        'relationship': relationship,
        'during': during
    }

    missing_fields = []
    if age == '미선택':
        missing_fields.append('나이대')
    if gender == '미선택':
        missing_fields.append('성별')
    if travel_type == '미선택':
        missing_fields.append('여행 유형')
    if region == '미선택':
        missing_fields.append('지역')
    if cost == '미선택':
        missing_fields.append('비용')
    if relationship == '미선택':
        missing_fields.append('관계')
    if during == '미선택':
        missing_fields.append('여행 기간')

    if missing_fields:
        flash(f"다음 항목들이 채워주세요: 관심사({', '.join(missing_fields)})")
        return redirect(request.url)

    file = request.files['file']

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        unique_filename = generate_unique_filename(filename)

        if unique_filename is None:
            return redirect(request.url)

        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        
        try:
            file.save(file_path)
            flash("글이 업로드 되었습니다.")
        except Exception as e:
            flash(f"파일 저장 중 오류 발생: {str(e)}")
            return redirect(request.url)

        # Add default likes=0 and comments field
        post_data = {
            'user_id': user_id,  # Add user_id to the post data
            'content': content,
            'image_path': f"uploads/{unique_filename}",
            'tags': tags,
            'likes': 0,  # Set default likes to 0
            'comments': []  # Initialize empty comments list
        }

        try:
            posts_collection.insert_one(post_data)
            flash('글이 업로드되었습니다.')
        except Exception as e:
            flash(f"MongoDB 저장 중 오류 발생: {str(e)}")
            return redirect(request.url)

        return redirect(url_for('write'))

    flash('허용되지 않는 파일 형식입니다.')
    return redirect(request.url)


@app.route('/search', methods=['GET'])
def search_get():
    query = request.args.get('query', '').strip()  # 검색어를 가져옵니다.
    
    posts = []

    if query:
        # Step 1: First, search for users whose nickname matches the query
        users = list(users_collection.find({"nickname": {"$regex": query, "$options": "i"}}))

        # Collect user_ids from matching users
        user_ids = [user['user_id'] for user in users]
        
        # Step 2: Search posts by matching tags or user_id
        posts = list(posts_collection.find({
            "$or": [
                {"tags.age": {"$regex": query, "$options": "i"}},
                {"tags.gender": {"$regex": query, "$options": "i"}},
                {"tags.travel_type": {"$regex": query, "$options": "i"}},
                {"tags.region": {"$regex": query, "$options": "i"}},
                {"tags.cost": {"$regex": query, "$options": "i"}},
                {"tags.relationship": {"$regex": query, "$options": "i"}},
                {"tags.during": {"$regex": query, "$options": "i"}},
                {"content": {"$regex": query, "$options": "i"}},
                {"user_id": {"$in": user_ids}}  # Search for posts by users with matching nicknames
            ]
        }))
    else:
        # 검색어가 없을 경우 모든 포스트를 가져옵니다.
        posts = list(posts_collection.find())

    # 포스트 데이터 처리
    for post in posts:
        post['_id'] = str(post['_id'])  # ObjectId를 문자열로 변환
        
        # Find the corresponding user from the users collection using user_id
        user = users_collection.find_one({'user_id': post['user_id']})
        post['nickname'] = user.get('nickname', 'Unknown User') if user else 'Unknown User'  # Get the nickname from the user collection
        
        post['region'] = post.get('tags', {}).get('region', 'Unknown Region')

    # JSON 형식으로 응답
    return jsonify({'posts': posts})





@app.route('/get_recommendations', methods=['POST'])
def get_recommendations():
    selected_region = request.json.get('region')

    if selected_region:
        pipeline = [
            {"$match": {"tags.region": selected_region}},  # 지역 필터링
            {"$sample": {"size": 2}}  # 무작위로 2개 선택
        ]
        posts = list(posts_collection.aggregate(pipeline))

        for post in posts:
            post['_id'] = str(post['_id'])  # ObjectId를 문자열로 변환
            post['image_path'] = url_for('static', filename=post['image_path'])  # 이미지 경로 처리

        return jsonify({"posts": posts})

    return jsonify({"posts": []}), 404

def get_most_common_tag_value(tag_name):
    pipeline = [
        {"$group": {"_id": f"$tags.{tag_name}", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 1}
    ]
    result = list(posts_collection.aggregate(pipeline))
    if result:
        return result[0]['_id']
    else:
        return "미선택"

@app.route('/add', methods=['POST'])
def add_document():
    data = request.json
    posts_collection.insert_one(data)
    return jsonify({"message": "Document added!"}), 201

@app.route('/documents', methods=['GET'])
def get_documents():
    documents = list(posts_collection.find({}, {"_id": 0}))  # MongoDB에서 문서를 가져오고, _id 필드 제외
    return jsonify(documents), 200

@app.route('/save_post/<post_id>', methods=['POST'])
def save_post(post_id):
    post_data = posts_collection.find_one({'_id': ObjectId(post_id)})

    if not post_data:
        return jsonify({'error': 'Post not found'}), 404

    # 게시물의 현재 saved 상태를 확인
    current_saved_status = post_data.get('saved', False)

    # 현재 상태와 반대로 설정
    new_saved_status = not current_saved_status

    # MongoDB 문서 업데이트
    posts_collection.update_one(
        {'_id': ObjectId(post_id)},
        {'$set': {'saved': new_saved_status}}
    )

    return jsonify({'saved': new_saved_status})

@app.route('/save')
def save():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    # 저장된 게시물만 필터링하여 가져오기
    saved_posts = list(posts_collection.find({'saved': True}))

    # 각 게시물의 이미지 데이터를 base64로 인코딩하여 템플릿에 전달
    for post in saved_posts:
        with open(os.path.join('static', post['image_path']), "rb") as image_file:
            image_data = image_file.read()
            post['image_data'] = base64.b64encode(image_data).decode('utf-8')

    return render_template('save.html', posts=saved_posts)

def calculate_character_image(stack_credit, nocheck):
    # Default character image based on stack_credit
    if stack_credit < 100:
        character_image = 'character_1.png'
    elif stack_credit < 300:
        character_image = 'character_2.png'
    elif stack_credit < 500:
        character_image = 'character_3.png'
    elif stack_credit < 800:
        character_image = 'character_4.png'
    else:
        character_image = 'character_5.png'

    # Modify character image based on nocheck value
    if nocheck < 10:
        character_image = character_image.replace('.png', '_default.png')
    elif 10 <= nocheck < 20:
        character_image = character_image.replace('.png', '_dust.png')
    elif 20 <= nocheck < 30:
        character_image = character_image.replace('.png', '_band.png')
    elif 30 <= nocheck < 40:
        character_image = character_image.replace('.png', '_poop.png')
    elif 40 <= nocheck < 50:
        character_image = character_image.replace('.png', '_fly.png')
    elif nocheck >= 50:
        character_image = character_image.replace('.png', '_ghost.png')

    return character_image
@app.route('/my')
def my():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    # Fetch user data from MongoDB
    user_data = users_collection.find_one({'user_id': user_id}, {'stack_credit': 1, 'nocheck': 1, 'profile_image': 1})
    
    if user_data:
        stack_credit = user_data.get('stack_credit', 0)
        nocheck = user_data.get('nocheck', 0)
        profile_image = user_data.get('profile_image', '/static/image/default_profile.png')
    else:
        stack_credit = 0
        nocheck = 0
        profile_image = '/static/image/default_profile.png'

    # Use the calculate_character_image function to determine the character image
    character_image = calculate_character_image(stack_credit, nocheck)

    # Fetch the latest posts by the logged-in user
    posts = list(posts_collection.find({'user_id': user_id}).sort('_id', -1).limit(2))
    for post in posts:
        post['_id'] = str(post['_id'])

    # Render the 'my' page with nocheck, character_image, and other data
    return render_template('my.html', posts=posts, character_image=character_image, profile_image=profile_image, nocheck=nocheck)





@app.route('/get_updated_character_image', methods=['POST'])
def get_updated_character_image():
    user_id = session.get('user_id')
    
    # Fetch the user data again to get the updated stack_credit and nocheck
    user_data = users_collection.find_one({'user_id': user_id}, {'stack_credit': 1, 'nocheck': 1})
    
    if user_data:
        stack_credit = user_data.get('stack_credit', 0)
        nocheck = user_data.get('nocheck', 0)

        # Use the calculate_character_image function to determine the character image
        character_image = calculate_character_image(stack_credit, nocheck)

        # Return the updated character image
        return jsonify({'success': True, 'character_image': character_image})
    
    return jsonify({'success': False, 'message': 'User not found'}), 404


@app.route('/reduce_nocheck', methods=['POST'])
def reduce_nocheck():
    data = request.get_json()
    user_id = session.get('user_id')

    # Fetch the user data
    user_data = users_collection.find_one({'user_id': user_id}, {'nocheck': 1})
    
    if user_data and 'nocheck' in user_data:
        # Decrease nocheck by 10
        new_nocheck = max(0, user_data['nocheck'] - 10)  # Make sure nocheck doesn't go below 0
        users_collection.update_one({'user_id': user_id}, {'$set': {'nocheck': new_nocheck}})
        
        return jsonify({'success': True, 'new_nocheck': new_nocheck})
    else:
        return jsonify({'success': False, 'message': 'User not found or nocheck not available'}), 404


@app.route('/deco')
def deco():
    # 나의 악세사리 페이지 렌더링
    return render_template('deco.html')

@app.route('/badge', methods=['GET', 'POST'])
def badge():
    # 여기에 POST 요청 처리 로직을 추가하거나 기본 GET 처리 로직을 유지합니다.

    user_id = session.get('user_id')  # 세션에서 현재 사용자 ID를 가져옵니다.
    if not user_id:
        return redirect(url_for('login'))  # 로그인이 안되어 있을 경우 로그인 페이지로 리다이렉트
    
    try:
        # MongoDB에서 user_id가 일치하는 게시물을 모두 찾고 리스트로 변환
        posts = list(posts_collection.find({'user_id': user_id}))
        print(f"가져온 게시물 수: {len(posts)}")  # 디버깅용 출력
    except Exception as e:
        print(f"MongoDB에서 게시물 찾는 중 오류 발생: {str(e)}")  # 디버깅용 출력
        flash(f"오류 발생: {str(e)}")
        return redirect(url_for('home'))  # 문제가 있을 경우 홈 페이지로 리다이렉트
    
    # 가져온 게시물을 템플릿에 전달
    return render_template('badge.html', posts=posts)






@app.route('/mypost')
def mypost():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    # Fetch posts for the logged-in user
    posts = list(posts_collection.find({'user_id': user_id}))

    # Convert MongoDB's ObjectId to a string for use in the template
    for post in posts:
        post['_id'] = str(post['_id'])

    # Pass the posts data to the 'mypost.html' template
    return render_template('mypost.html', posts=posts)

@app.route('/mypost/<post_id>')
def view_mypost(post_id):
    # Find the post by its ID
    post = posts_collection.find_one({"_id": ObjectId(post_id)})

    if not post:
        return "Post not found", 404

    # Debugging output
    print("Post content:", post.get('post_content'))

    # Find the user by the post's user_id
    user = users_collection.find_one({"user_id": post['user_id']})

    if not user:
        return "User not found", 404

    # Add the user's profile image and nickname to the post object
    # Default to 'default_profile.png' if profile image is not found
    post['profile_image'] = user.get('profile_image', 'default_profile.png')
    post['nickname'] = user.get('nickname', '익명')

    # Generate the image path for the post image
    image_path = os.path.join('static', post['image_path'])

    if not os.path.exists(image_path):
        return "Image not found", 404

    with open(image_path, "rb") as image_file:
        post['image_data'] = base64.b64encode(image_file.read()).decode('utf-8')

    # Render the template with the post data including the user's profile image and nickname
    return render_template('myPostDetail.html', post=post)


@app.route('/add_comment/<post_id>', methods=['POST'])
def add_comment(post_id):
    # Get the form data
    comment_text = request.form.get('comment', '').strip()
    user_id = session.get('user_id')

    if not user_id:
        return jsonify({"success": False, "error": "로그인이 필요합니다."}), 401

    # Fetch the user's nickname from the database
    user_data = users_collection.find_one({'user_id': user_id})
    if not user_data or 'nickname' not in user_data:
        return jsonify({"success": False, "error": "사용자의 닉네임을 찾을 수 없습니다."}), 400

    nickname = user_data['nickname']

    if not comment_text:
        return jsonify({"success": False, "error": "댓글을 입력해주세요."}), 400

    # Fetch the post by ID
    post = posts_collection.find_one({"_id": ObjectId(post_id)})
    if not post:
        return jsonify({"success": False, "error": "게시물을 찾을 수 없습니다."}), 404

    # Prepare the comment data
    comment = {'nickname': nickname, 'text': comment_text}

    # Push the comment into the post's comments array
    posts_collection.update_one({'_id': ObjectId(post_id)}, {'$push': {'comments': comment}})

    return jsonify({"success": True, "comment": comment}), 200






@app.route('/like/<post_id>', methods=['POST'])
def like(post_id):
    user_id = session.get('user_id')  # Get the user_id from the session
    if not user_id:
        return jsonify({'error': 'User not logged in'}), 401

    # Fetch the post data from MongoDB
    post_data = posts_collection.find_one({'_id': ObjectId(post_id)})

    if not post_data:
        return jsonify({'error': 'Post not found'}), 404

    # Check if the user has already liked the post
    if 'liked_by' not in post_data:
        post_data['liked_by'] = []

    if user_id in post_data['liked_by']:
        # If the user has already liked the post, remove the like
        posts_collection.update_one(
            {'_id': ObjectId(post_id)},
            {'$inc': {'likes': -1}, '$pull': {'liked_by': user_id}}
        )
        new_like_status = False
    else:
        # If the user hasn't liked the post yet, add a like
        posts_collection.update_one(
            {'_id': ObjectId(post_id)},
            {'$inc': {'likes': 1}, '$push': {'liked_by': user_id}}
        )
        new_like_status = True

    # Get the updated post data to return the new like count
    updated_post = posts_collection.find_one({'_id': ObjectId(post_id)})

    return jsonify({
        'likes': updated_post.get('likes', 0),
        'liked_by_user': new_like_status
    })



@app.route('/delete_post/<post_id>', methods=['POST'])
def delete_post(post_id):
    try:
        # MongoDB에서 해당 게시물 삭제
        result = posts_collection.delete_one({'_id': ObjectId(post_id)})
        if result.deleted_count > 0:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': '삭제할 게시물을 찾을 수 없습니다.'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'게시물 삭제 중 오류 발생: {str(e)}'})
    return redirect(url_for('mypost'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    query = request.args.get('query', '')  # 검색어를 가져옵니다. 기본값은 빈 문자열
    print(f"검색어: {query}")  # 검색어를 출력하여 확인
    
    if query:
        # 검색어와 태그가 일치하는 포스트를 필터링합니다.
        posts = list(posts_collection.find({"tags": {"$regex": query, "$options": "i"}}))
        print(f"필터링된 포스트 개수: {len(posts)}")  # 필터링된 결과의 개수 출력
    else:
        # 검색어가 없을 경우 모든 포스트를 가져옵니다.
        posts = list(posts_collection.find())
        print(f"모든 포스트 개수: {len(posts)}")  # 전체 결과의 개수 출력

    # 각 포스트의 이미지 데이터를 base64로 인코딩합니다.
    for post in posts:
        with open(os.path.join('static', post['image_path']), "rb") as image_file:
            image_data = image_file.read()
            post['image_data'] = base64.b64encode(image_data).decode('utf-8')
        
        # 템플릿에서 사용하기 쉽게 데이터 변환
        post['username'] = post.get('username', 'Anonymous')
        post['location'] = post.get('location', 'Unknown')
        post['post_content'] = post.get('content', '')
        post['tags'] = list(post.get('tags', {}).values())

    user_name = "YourUserName"
    return render_template('search.html', posts=posts, user_name=user_name)
@app.route('/hotpost')
def hotpost():
    # 나의 악세사리 페이지 렌더링
    return render_template('hotpost.html')


@app.route('/search', methods=['GET'])
def searchpost():
    query = request.args.get('query', '').strip()  # 검색어를 가져옵니다.
    print(f"Received query: {query}")  # 디버그용으로 쿼리 출력

    if query:
        # 각 태그 필드에 대해 검색어가 포함된 포스트를 찾습니다.
        posts = list(posts_collection.find({
            "$or": [
                {"tags.age": {"$regex": query, "$options": "i"}},
                {"tags.gender": {"$regex": query, "$options": "i"}},
                {"tags.travel_type": {"$regex": query, "$options": "i"}},
                {"tags.region": {"$regex": query, "$options": "i"}},
                {"tags.cost": {"$regex": query, "$options": "i"}},
                {"tags.relationship": {"$regex": query, "$options": "i"}},
                {"tags.during": {"$regex": query, "$options": "i"}}
            ]   
        }))
        print(f"Found posts: {len(posts)}")

    else:
        # 검색어가 없을 경우 모든 포스트를 가져옵니다.
        posts = list(posts_collection.find())
        print(f"Found posts without query: {len(posts)}")

    # 각 포스트의 이미지 데이터를 base64로 인코딩합니다.
    for post in posts:
        with open(os.path.join('static', post['image_path']), "rb") as image_file:
            image_data = image_file.read()
            post['image_data'] = base64.b64encode(image_data).decode('utf-8')
        
        # 템플릿에서 사용하기 쉽게 데이터 변환
        post['username'] = post.get('username', 'Anonymous')
        post['location'] = post.get('location', 'Unknown')
        post['post_content'] = post.get('content', '')
        post['tags'] = list(post.get('tags', {}).values())

    user_name = session.get('username', '익명')  # 사용자 이름을 세션에서 가져옵니다.
    return render_template('search.html', posts=posts, user_name=user_name)

@app.route('/change_profile', methods=['GET', 'POST'])
def change_profile():
    user_id = session.get('user_id')  # Get user_id from session

    if not user_id:
        return redirect(url_for('login'))  # Redirect to login if no user is logged in

    if request.method == 'POST':
        # Access the uploaded file from the form
        profile_image = request.files.get('profile_image')
        upload_folder = 'static/image/uploads_profile'  # Folder to store uploaded profile images

        # Ensure the upload folder exists
        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        if profile_image:
            # Save the uploaded image to the specified folder
            file_path = os.path.join(upload_folder, profile_image.filename)
            profile_image.save(file_path)

            # Prepare the path to store in the database
            profile_image_path = f'/static/image/uploads_profile/{profile_image.filename}'

            # Update the user's profile image in the database
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {
                    "profile_image": profile_image_path
                }}
            )
        else:
            # If no image is uploaded, set the default profile image
            profile_image_path = '/static/image/profile.png'
            users_collection.update_one(
                {"user_id": user_id},
                {"$set": {
                    "profile_image": profile_image_path
                }}
            )

        # Redirect to the settings page after uploading
        return redirect(url_for('setting'))

    return render_template('setting.html')

@app.route('/post/<post_id>')  # post
def post(post_id):
    post_data = posts_collection.find_one({'_id': ObjectId(post_id)})

    if not post_data:
        return "No posts found", 404

    # Fetch the user_id from the post_data
    user_id = post_data.get('user_id')

    # Fetch the user who created the post
    user = users_collection.find_one({"user_id": user_id})

    if not user:
        return "User not found", 404

    # Add the user's profile image and nickname to the post object
    post_data['profile_image'] = user.get('profile_image', 'default_profile.png')
    post_data['nickname'] = user.get('nickname', '익명')

    # Keep the tags as a dictionary for easier access in the template
    post_data['username'] = post_data.get('username', 'Anonymous')
    
    post_data['post_content'] = post_data.get('content', '')
    post_data['tags'] = post_data.get('tags', {})  # Leave it as a dictionary
    post_data['comments'] = post_data.get('comments', [])  # 댓글 추가
    post_data['likes'] = post_data.get('likes', 0)  # 좋아요 수 추가
    post_data['like_by_user'] = session.get('user_id') in post_data.get('like_by', [])  # Check if current user liked the post

    # 이미지 데이터 처리 (파일 경로를 전달하거나 base64로 인코딩)
    image_path = os.path.join('static', post_data['image_path'])

    if not os.path.exists(image_path):
        return "Image not found", 404

    with open(image_path, "rb") as image_file:
        image_data_base64 = base64.b64encode(image_file.read()).decode('utf-8')

    post_data['image_data'] = image_data_base64
    post_data['image_filename'] = os.path.basename(post_data['image_path'])

    return render_template('post.html', post=post_data)



@app.route('/setting')
def setting():
    user_id = session.get('user_id')

    if not user_id:
        return redirect(url_for('login'))

    #Fetch user data from MongoDB based on user_id
    user_data = users_collection.find_one({'user_id': user_id}, 
                                          {'_id': 0, 'nickname': 1, 'name': 1, 'phone_number': 1, 'profile_image': 1, 
                                           'gender': 1, 'age': 1, 'prefer': 1, 'user_id': 1, 'password': 1, 'type': 1})

    if not user_data:
        flash("User data not found.")
        return redirect(url_for('home'))

    # Extract values from the user_data
    nickname = user_data.get('nickname', 'Unknown')
    name = user_data.get('name', 'Unknown')
    phone_number = user_data.get('phone_number', 'Unknown')
    profile_image = user_data.get('profile_image', '/static/image/default_profile.png')
    gender = user_data.get('gender', 'Unknown')
    age = user_data.get('age', 'Unknown')
    prefer = user_data.get('prefer', 'Unknown')
    user_id_value = user_data.get('user_id', 'Unknown')
    password = user_data.get('password', '********')
    user_type = user_data.get('type', 'general')

    # Determine login_id based on type
    if user_type == 'naver':
        login_id = 'naver-login'
    elif user_type == 'kakao':
        login_id = 'kakao-login'
    elif user_type == 'google':
        login_id = 'google-login'
    else:
        login_id = user_id_value  # Use the user_id for general type

    # Render the settings page with the user data
    return render_template('setting.html', 
                           nickname=nickname, 
                           name=name, 
                           phone_number=phone_number, 
                           profile_image=profile_image,
                           gender=gender, 
                           age=age, 
                           prefer=prefer, 
                           login_id=login_id, 
                           password=password,
                           user_type=user_type)  # Pass user_type to the template





@app.route('/change_phone', methods=['GET', 'POST'])
def change_phone():
    user_id = session.get('user_id')  # Get the logged-in user_id from the session
    if request.method == 'POST':
        phone_number = request.form['phone_number']

        # Check if the verification code was submitted
        verification_code = request.form.get('verification_code')
        saved_code = session.get('verification_code')

        # Allow "test-user" to bypass verification
        if verification_code == "test-user" or (verification_code and saved_code):
            # Verify the code
            if verification_code == "test-user" or verification_code == saved_code:
                # Code matches, save the phone number to the database
                users_collection.update_one(
                    {"user_id": user_id},
                    {"$set": {"phone_number": phone_number}}
                )
                session.pop('verification_code', None)  # Remove the code from session after use
                return redirect(url_for('setting'))  # Ensure the redirection is to 'setting'
            else:
                # Code doesn't match, show an error message
                flash('인증번호가 일치하지 않습니다. 다시 시도해주세요.')
        else:
            # No verification code submitted yet, so send one
            sent_code = send_verification_code(phone_number)
            if sent_code:
                session['verification_code'] = str(sent_code)  # Save the code in session
                flash('인증번호가 전송되었습니다. 확인 후 입력해주세요.')
            else:
                flash('메시지 전송에 실패했습니다. 나중에 다시 시도해주세요.')

    return render_template('change-phone.html')




@app.route('/change-password', methods=['GET', 'POST'])
def change_password_handler():
    if request.method == 'POST':
        user_id = session.get('user_id')
        if not user_id:
            return redirect(url_for('login'))  # 로그인하지 않았을 경우, 로그인 페이지로 리디렉션

        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # 비밀번호와 확인 비밀번호가 일치하는지 확인
        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('change_password_handler'))

        # scrypt로 비밀번호 해시 생성
        hashed_password = hash_password(password)

        # 데이터베이스에 해시된 비밀번호 업데이트
        users_collection.update_one({'user_id': user_id}, {'$set': {'password': hashed_password}})

        flash('Password updated successfully')
        return redirect(url_for('setting'))

    # GET 요청인 경우, 비밀번호 변경 폼 렌더링
    return render_template('change-password.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)  # 세션에서 'user_id' 제거
    return redirect(url_for('login'))  # 로그아웃 후 로그인 페이지로 리다이렉트




@app.route('/change-age', methods=['GET', 'POST'])
def change_age():
    if request.method == 'POST':
        # Retrieve selected age and user_id from session
        selected_age = request.form.get('age')
        user_id = session.get('user_id')

        if user_id and selected_age:
            # Update the user's age in the database
            users_collection.update_one({'user_id': user_id}, {'$set': {'age': selected_age}})
        
        # Redirect to setting.html after successful update
        return redirect(url_for('setting'))

    # Render the form if the request method is GET
    return render_template('change_age.html')

@app.route('/change-prefer', methods=['GET', 'POST'])
def change_prefer():
    if request.method == 'POST':
        # Retrieve selected preference and user_id from session
        selected_prefer = request.form.get('prefer')
        user_id = session.get('user_id')

        if user_id and selected_prefer:
            # Update the user's preference in the database
            users_collection.update_one({'user_id': user_id}, {'$set': {'prefer': selected_prefer}})
        
        # Redirect to setting.html after successful update
        return redirect(url_for('setting'))

    # Render the form if the request method is GET
    return render_template('change_prefer.html')

@app.route('/change-gender', methods=['GET', 'POST'])
def change_gender():
    if request.method == 'POST':
        # Retrieve selected gender and user_id from session
        selected_gender = request.form.get('gender')
        user_id = session.get('user_id')

        if user_id and selected_gender:
            # Update the user's gender in the database
            users_collection.update_one({'user_id': user_id}, {'$set': {'gender': selected_gender}})
        
        # Redirect to setting.html after successful update
        return redirect(url_for('setting'))

    # Render the form if the request method is GET
    return render_template('change_gender.html')



if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)



